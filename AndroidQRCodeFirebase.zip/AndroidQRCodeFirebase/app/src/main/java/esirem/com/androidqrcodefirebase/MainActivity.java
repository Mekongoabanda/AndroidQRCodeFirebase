package esirem.com.androidqrcodefirebase;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.ml.vision.FirebaseVision;
import com.google.firebase.ml.vision.barcode.FirebaseVisionBarcode;
import com.google.firebase.ml.vision.barcode.FirebaseVisionBarcodeDetector;
import com.google.firebase.ml.vision.barcode.FirebaseVisionBarcodeDetectorOptions;
import com.google.firebase.ml.vision.common.FirebaseVisionImage;
import com.wonderkiln.camerakit.CameraKitError;
import com.wonderkiln.camerakit.CameraKitEvent;
import com.wonderkiln.camerakit.CameraKitEventListener;
import com.wonderkiln.camerakit.CameraKitImage;
import com.wonderkiln.camerakit.CameraKitVideo;
import com.wonderkiln.camerakit.CameraView;

import java.util.List;

import dmax.dialog.SpotsDialog;

public class MainActivity extends AppCompatActivity {

    CameraView cameraView;
    Button btnDetect;
    AlertDialog waitingDialog;

    @Override
    protected void onResume() {
        super.onResume();
        //Lorsque l'activité reprend la camera redemarre
        cameraView.start();
    }

    @Override
    protected void onPause() {
        super.onPause();
        //Lorsque l'activité reprend la camera s'arrête
        cameraView.stop();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_main );

        //Appareil photo en mode portrait
        setRequestedOrientation( ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        cameraView = (CameraView) findViewById( R.id.cameraView );
        btnDetect = (Button) findViewById ( R.id.btn_detect );

        //Dialogue d'alerte
        waitingDialog = new SpotsDialog.Builder()
                .setContext( this )
                .setMessage( "Patientez s'il-vous-plait" )
                .setCancelable( false )
                .build();

        //Lorsque l'on click sur le bouton
        btnDetect.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //La camera se met en marche
                cameraView.start();
                //La camera capture l'image
                cameraView.captureImage();

            }
        } );

        //Evenement lié à la lecture de la camera
        cameraView.addCameraKitListener( new CameraKitEventListener() {
            @Override
            public void onEvent(CameraKitEvent cameraKitEvent) {


            }

            @Override
            public void onError(CameraKitError cameraKitError) {

            }
            //Dans le cas d'une Image
            @Override
            public void onImage(CameraKitImage cameraKitImage) {

                waitingDialog.show();
                Bitmap bitmap = cameraKitImage.getBitmap();
                bitmap = Bitmap.createScaledBitmap( bitmap, cameraView.getWidth(), cameraView.getHeight(), false );
                cameraView.stop();

                runDetector(bitmap);
            }

            @Override
            public void onVideo(CameraKitVideo cameraKitVideo) {

            }
        } );

    }

    private void runDetector(Bitmap bitmap) {

        FirebaseVisionImage image = FirebaseVisionImage.fromBitmap( bitmap );
        FirebaseVisionBarcodeDetectorOptions options = new FirebaseVisionBarcodeDetectorOptions.Builder()
        .setBarcodeFormats(
                FirebaseVisionBarcode.FORMAT_QR_CODE,

                FirebaseVisionBarcode.FORMAT_PDF417 // Format de l'image (extension)
        ).build();

        FirebaseVisionBarcodeDetector detector = FirebaseVision.getInstance().getVisionBarcodeDetector(options);
        detector.detectInImage( image )
                .addOnSuccessListener( new OnSuccessListener<List<FirebaseVisionBarcode>>() {
                    @Override
                    public void onSuccess(List<FirebaseVisionBarcode> firebaseVisionBarcodes) {

                        //Si la detection de l'image est un succès on appel la procéure suivante
                        processResult(firebaseVisionBarcodes);
                    }
                } )
                .addOnFailureListener( new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {

                        Toast.makeText( MainActivity.this, e.getMessage(), Toast.LENGTH_SHORT ).show();

                    }
                } );
    }

    //Procedure qui contient l'algorithme que le'on effectuera en cas de réussite de la detection du QR code
    private void processResult(List<FirebaseVisionBarcode> firebaseVisionBarcodes) {

        for(FirebaseVisionBarcode item : firebaseVisionBarcodes ) {

            int value_type = item.getValueType();

            switch (value_type){

                case FirebaseVisionBarcode.TYPE_TEXT:
                {
                    AlertDialog.Builder builder = new AlertDialog.Builder(this);
                    builder.setMessage( item.getRawValue() );

                    builder.setPositiveButton( "OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int which) {

                            dialogInterface.dismiss();

                        }
                    } );
                   AlertDialog dialog = builder.create();
                    dialog.show();
                }
                break;

                case FirebaseVisionBarcode.TYPE_URL:
                {
                    //Commencer la recherche de l'url
                    Intent intent = new Intent ( Intent.ACTION_VIEW, Uri.parse(item.getRawValue()));
                    startActivity(intent);


                }
                break;

                case FirebaseVisionBarcode.TYPE_CONTACT_INFO:
                {
                    String info = new StringBuilder( "Name : " )
                            .append( item.getContactInfo().getName().getFormattedName())
                            .append( "\n" )
                            .append( "Address : " )
                            .append( item.getContactInfo().getAddresses().get( 0 ).getAddressLines() )
                            .append( "\n" )
                            .append( "Email : " )
                            .append( item.getContactInfo().getEmails().get( 0 ).getAddress() )
                            .toString();

                    AlertDialog.Builder builder = new AlertDialog.Builder(this);
                    builder.setMessage( info );

                    builder.setPositiveButton( "OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int which) {

                            dialogInterface.dismiss();

                        }
                    } );
                    AlertDialog dialog = builder.create();
                    dialog.show();
                }
                break;

                default:
                    break;
            }
        }

        waitingDialog.dismiss();
    }
}
